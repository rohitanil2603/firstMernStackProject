const express = require("express");

const authRoutes= express.Router();

// importing controller 
const {createUser} = require("../controllers/auth")
const {loginUser} = require("../controllers/auth");

//importing middlewares
const {auth}= require("../middlewares/Auth")
const {isStudent}= require("../middlewares/Auth")
const {isAdmin}= require("../middlewares/Auth")

// creating routes
authRoutes.post("/auth/signUp",createUser)
authRoutes.post("/auth/login",loginUser)

// protected routes {in these routes we are using middlewares}
authRoutes.get("/test",auth,(req,res)=>{res.send("<h1> you are authenticated user </h1>")})
authRoutes.get("/student",auth,isStudent,(req,res)=>{res.send("<h1> welcome to student routes </h1>")})
authRoutes.get("/admin",auth,isAdmin,(req,res)=>{res.send("<h1> welcome to admin routes </h1>")})


// exporting router
module.exports= authRoutes