const mongoose = require("mongoose");
require("dotenv").config();

const DB_URL = process.env.DB_URL;

const db_connect = async () => {
  try {
    await mongoose.connect(DB_URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log("database connected successfully");
  } catch (error) {
    console.log(error);
    console.log("failed to connect to database");
    process.exit(1);
  }
};
module.exports = db_connect;
