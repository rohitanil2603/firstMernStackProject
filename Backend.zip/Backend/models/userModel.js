const mongoose= require("mongoose");

const userSchema = mongoose.Schema({
    name:{
        type:String,
        required:true,
        maxlength:60
    },
    email:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true,
        maxlength:200
    },
    role:{
        type:String,
        required:true,
        maxlength:40
    },

})


module.exports= mongoose.model("User",userSchema);