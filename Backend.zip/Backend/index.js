const express= require("express")
require("dotenv").config()
const db_connect= require('./config/db_config')
const authRoutes= require("./routes/authRoutes")
// importing cookie parser
const cookieParser= require("cookie-parser")
const CORS= require("cors")

const PORT= process.env.PORT || 4000

const app= express();
// connect to database
db_connect();

// enabling CORS
app.use(CORS());

// assigning middleware
app.use(express.json());
app.use(cookieParser()); 

// mounting routes
app.use("/api/v1",authRoutes)   

app.listen(PORT,()=>{
    console.log("app is live ")
})

app.get('/',(req,res)=>{ 
    res.send("<h1>This is home page baby..! </h1>")
})