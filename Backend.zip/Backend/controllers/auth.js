const User = require("../models/userModel");
const bcrypt = require("bcrypt");
const saltRounds = 10;
const jwt = require("jsonwebtoken");
require("dotenv").config();

exports.createUser = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    // to check if user already exists
    const userAlreadyExist = await User.findOne({ email: email });
    // if user exist return with error
    if (userAlreadyExist) {
      return res.status(400).json({
        success: false,
        message: "user with this email id already exist",
      });
    }
    // if user does not exist then create
    // create password
    try {
      const hashPassword = await bcrypt.hash(password, saltRounds);

      // if hash password is created then create user object
      const user = new User({
        name,
        email,
        password: hashPassword,
        role,
      });

      const saveduser = await user.save();

      // user created return with success
      return res.status(200).json({
        success: true,
        message: "user created sucecssfully",
        data: saveduser,
      });
    } catch (error) {
      return res.status(400).json({
        success: false,
        data: error,
        message: "error creating hash password",
      });
    }
  } catch (error) {
    console.error(error);
    console.log(error);
    return res.status(500).json({
      success: false,
      data: error,
      message: "failed to create user",
    });
  }
};

// to login user
exports.loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    // check if email and password is not NULL
    if (!email || !password) {
      return res.status(401).json({
        success: false,
        message: "password or email is NULL",
      });
    }
    // if email and password is set check if user account exists
    const userExist = await User.findOne({ email: email });

    if (!userExist) {
      return res.status(402).json({
        success: false,
        message: "account does not exist with this email",
      });
    }

    // if account exist then compare password
    if (!(await bcrypt.compare(password, userExist.password))) {
      return res.status(403).json({
        success: false,
        message: "incorrect password",
      });
    }
    // if password is correct then create JWT token and login user
    const JWT_SECRET = process.env.JWT_SECRET;
    const payload = {
      email: userExist.email,
      role: userExist.role,
      _id: userExist._id,
    };
    const options = {
      expires: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      httpOnly: true,
    };
    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: "3days" });

    // removing password and adding token to user object
    // userExist.password=undefined
    // userExist.token=token

    // Create a new object with updated properties
    const updatedUserExist = {
      name: userExist.name,
      email: userExist.email,
      role: userExist.role,
      _id: userExist._id,
      token: token,
    };

    return res.cookie("rohitCookie", token, options).status(200).json({
      success: true,
      message: "login successfully",
      data: updatedUserExist,
    });
  } catch (error) {
    console.log(error);

    return res.status(500).json({
      success: false,
      message: "failed to login",
      data: error,
    });
  }
};
