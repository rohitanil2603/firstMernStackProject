/* In this code there are 3 middlewares 
auth: to check if user is authenticated
student: to check if user has student role
admin: to check if user has admin role */

const jwt = require("jsonwebtoken");
require("dotenv").config();

exports.auth = (req, res, next) => {
  try {
    // console.log(req.cookies);
    const token = req.body.token || req.cookies.rohitCookie || req.header("Authorization").replace("Bearer ","");
  
    if (!token) {
      return res.status(400).json({
        success: false,
        message: "token not found",
      });
    }
    // decode the token
    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET);

      // if token is decoded correctly then store payload in req (request)
      req.user = payload;
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: "Invalid token",
      });
    }

    // call the next middleware
    next();
  } catch (error) {
    return res.status(400).json({
      success: false,
      message: "error while chekcing if user is authorised",
      data: error,
    });
  }
};

// to check if user is student
exports.isStudent = (req, res, next) => {
  try {
    // check if user is student
    if (req.user.role == "Student") {
      // user is student
      // call the next middleware
      next();
    } else {
      return res.status(402).json({
        success: false,
        message: "This is protected route of Student you cannot access it",
      });
    }
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "error while checking user role",
      data: error,
    });
  }
};

// to check if user is admin
exports.isAdmin = (req, res, next) => {
  try {
    // check if user is student
    if (req.user.role == "Admin") {
      // user is student
      // call the next middleware
      next();
    } else {
      return res.status(402).json({
        success: false,
        message: "This is protected route of Admin you cannot access it",
      });
    }
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "error while checking user role",
      data: error,
    });
  }
};
